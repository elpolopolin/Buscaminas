# Como ver correctamente las correcciones?
- Para la correcta visualización de las correcciones hechas en el código:
    - Se debe instalar la extensión "Colorful Comments" en VSCode (link: https://marketplace.visualstudio.com/items?itemName=ParthR2031.colorful-comments). Esta extension agrega colores a los comentarios según su tipo, con lo que se pueden diferenciar sus comentarios de mis correcciones.
- Dado que los comentarios fueron realizados sin saltos de linea se recomienda activar el modo "Word Wrap" en VSCode para que se vean correctamente.
    - Activar/Desactivar Word Wrap: "Alt + Z" (Windows/Linux), "⌘ + Z" (macOS)
    (o desde el menu superior "View"/"Ver" -> "Word Wrap"/"Ajuste de palabra").

# Las correcciones se encuentran dentro de buscaminas.py y su archivo de test correspondiente.
- DESAPROBADO
